package com.dicoding.submissiongithub.iu

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.dicoding.submissiongithub.data.response.DetailUserResponse
import com.dicoding.submissiongithub.databinding.ActivityDetailBinding

class DetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val mainViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(MainViewModel::class.java)

        mainViewModel.detailUser.observe(this) {detailUserRespone ->
            setDetailData(detailUserRespone)
        }

        mainViewModel.isLoading.observe(this) {
            showLoading(it)
        }
    }

    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
        }
    }

    private fun setDetailData(detailUserResponse: DetailUserResponse) {
        binding.tvUsername.text = detailUserResponse.login
        binding.tvName.text = detailUserResponse.name
        binding.tvFollowers.text = "Followers: ${detailUserResponse.followers}"
        binding.tvFollowing.text = "Following: ${detailUserResponse.following}"
        Glide.with(this)
            .load(detailUserResponse.avatarUrl)
            .into(binding.ivDetail)
    }
}